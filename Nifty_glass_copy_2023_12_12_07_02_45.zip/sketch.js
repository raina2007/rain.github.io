
//declare variables x and y
var x = 450;
var y = 450;
function setup() {
 createCanvas(900, 900);
 //black background
 background(0,0,0);
}
//the draw()function is an infinite loop
function draw() {
  for (let i=0; i<100;i++){
 //colour dots green
 stroke('green');
 //at random pick a number between 1 and 3
 var corner = random(1,3);
 //round to nearest integer
 corner = round(corner);
 //treat corner 1 as point A (450,0)
 if (corner==1){
 //code midpoint
 x = (x+450)/2;
 y = (y+0)/2;
 //output point to canvas
 point(x,y);
 }//end if

 //treat corner 2 as point B (900,900)
 if (corner==2){
 //code midpoint
 x = (x+900)/2;
 y = (y+900)/2;
 //output point to canvas
 point(x,y);
 }//end if
  
 //treat corner 3 as point A (0,900)
 if (corner==3){
   //code midpoint
 x = (x+0)/2;
 y = (y+900)/2;
 //output point to canvas
 point(x,y);
   
 }//end if
  }
}//end draw() 